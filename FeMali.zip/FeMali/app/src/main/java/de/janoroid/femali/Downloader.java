package de.janoroid.femali;

import android.os.AsyncTask;

public class Downloader extends AsyncTask<Void,Void,Object> {
    @Override
    protected Object doInBackground(Void... voids) {
        return null;
    }
}
